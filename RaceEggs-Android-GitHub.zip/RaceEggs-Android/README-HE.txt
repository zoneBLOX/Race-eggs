RACE EGGS - אפליקציית Android (פרויקט מקור)

זהו פרויקט Android Studio, לא APK מוכן.

איך לבנות APK ב-Linux Mint:
1. התקן Android Studio מאתר developer.android.com/studio
2. חלץ את קובץ ה-ZIP.
3. ב-Android Studio בחר Open ובחר את תיקיית RaceEggs-Android.
4. המתן לסיום Gradle Sync ולהורדת רכיבי Android SDK אם תתבקש.
5. בחר Build > Build Bundle(s) / APK(s) > Build APK(s).
6. קובץ ה-APK יופיע תחת app/build/outputs/apk/debug/app-debug.apk.
7. העבר אותו לטלפון והתקן רק אם אתה סומך על הקובץ ועל מקורו.

המשחק נפתח במסך מלא לרוחב עם כפתורי מגע.
נדרש אינטרנט כדי לטעון את ספריית Three.js.
אין Multiplayer בגרסה זו; ההתקדמות נשמרת על המכשיר.
הפרויקט לא נבנה ולא נבדק על מכשיר Android בסביבה הנוכחית.
