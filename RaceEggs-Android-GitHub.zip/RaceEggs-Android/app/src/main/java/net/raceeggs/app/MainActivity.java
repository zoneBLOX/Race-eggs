package net.raceeggs.app;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
public class MainActivity extends Activity {
 WebView web;
 @Override public void onCreate(Bundle b) { super.onCreate(b);
 getWindow().getDecorView().setSystemUiVisibility(5894 | View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
 web=new WebView(this);web.setWebViewClient(new WebViewClient());web.setWebChromeClient(new WebChromeClient());
 web.getSettings().setJavaScriptEnabled(true);web.getSettings().setDomStorageEnabled(true);
 web.getSettings().setAllowFileAccess(false);web.getSettings().setAllowContentAccess(false);
 setContentView(web);
 try(InputStream in=getAssets().open("index.html")){byte[] bytes=new byte[in.available()];int offset=0,n;while(offset<bytes.length && (n=in.read(bytes,offset,bytes.length-offset))>0)offset+=n;
 String html=new String(bytes,0,offset,StandardCharsets.UTF_8);
 web.loadDataWithBaseURL("https://raceeggs.local/",html,"text/html","UTF-8",null);
 }catch(Exception e){web.loadData("Could not load game","text/html","UTF-8");}
 }
 @Override public void onBackPressed(){if(web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onDestroy(){web.destroy();super.onDestroy();}
}